import pandas as pd
import urllib.request
from ripe.atlas.sagan import Result
import json
from multiprocessing import Pool
from tqdm import tqdm
import time
import pickle
from util import *
import os


# Declare global variables
global_anchor_data = {}
unknown_sources = []

def infer_anchors(page_num,start_time = "1651380026",protocol = 'IPv4')
    """
    Function to infer anchor measurements from the RIPE Atlas API, process the data,
    and store the results in a global dictionary.

    Args:
        page_num (int): Page number of the API request
        start_time (str): Start time of the measurement
        protocol (str): Protocol considered (either IPv4 or IPv6)
    """

    # Check if the file already exists, if so, skip the processing
    file_name = f'Datasets/AnchorMeasurements/AnchorMeshes{page_num}.json'
    for _, _, files in os.walk('Datasets/AnchorMeasurements/'):
        if file_name in files:
            print('file already exists')
            return

    start_time = time.process_time()

    # Fetch anchor measurements data from the API
    api_url = f"https://atlas.ripe.net/api/v2/anchor-measurements/?format=json&page={page_num}"
    with urllib.request.urlopen(api_url) as anchor_results:
        for anchor_result in anchor_results.readlines():
            anchor_data = json.loads(anchor_result.decode("utf-8"))

            # Iterate through the results to process only mesh ping measurements
            for measurement in anchor_data['results']:
                if measurement['type'] == 'ping' and measurement['is_mesh']:
                    print(measurement['target'])

                    # Attempt to fetch target data from the API
                    try:
                        with urllib.request.urlopen(measurement['target']) as results:
                            for result in results.readlines():
                                target_data = json.loads(result.decode("utf-8"))
                                target_coordinates = target_data['geometry']['coordinates']

                                # Check if the probe exists in the DataFrame
                                probe_df = df[df.index == target_data['probe']][['longitude', 'latitude']]
                                if not probe_df.empty:
                                    probe_coordinates = probe_df.values[0]

                                # Check if the values exceed the threshold
                                if probe_coordinates[0]-target_coordinates[0] + probe_coordinates[1]-target_coordinates[1] > 1:
                                    continue
                    except:
                        unknown_sources.append(measurement['target'])
                        continue
                    # Fetch and process measurement data
                    source = target_data['probe']
                    with urllib.request.urlopen(measurement['measurement']) as results:
                        for result in tqdm(results.readlines()):
                            measurement_data = json.loads(result.decode("utf-8"))
                            split_result = measurement_data['result'].split('?')
                            timebound_url = split_result[0]+f"?start={start_time}&format=txt"
                            missing_probes = []
                            missing_indices = []
                            print(timebound_url)

                            # Fetch and process atlas results
                            with urllib.request.urlopen(timebound_url) as atlas_res:
                                if protocol in measurement_data['description']:
                                    probe_rtt_min = {}
                                    for (i, atlas_result) in tqdm(enumerate(atlas_res.readlines())):
                                        atlas_data = Result.get(atlas_result.decode("utf-8"))

                                        if atlas_data.rtt_min is not None:
                                            if atlas_data.probe_id in probe_rtt_min.keys():
                                                if probe_rtt_min[atlas_data.probe_id] > atlas_data.rtt_min:
                                                    probe_rtt_min[atlas_data.probe_id] = atlas_data.rtt_min
                                            else:
                                                probe_rtt_min.update({atlas_data.probe_id: atlas_data.rtt_min})
                                        else:
                                            missing_probes.append(str(atlas_data.probe_id))
                                            missing_indices.append((i))

                                    # Check for missing keys in the dictionary
                                    failed_count = 0
                                    for key in list(set(missing_probes)):
                                        try:
                                            print(probe_rtt_min[key])
                                        except:
                                            failed_count += 1
                                    global_anchor_data[source] = probe_rtt_min
                                    break

                                else:
                                    break
                                # Save the global dictionary as a JSON file
                                with open('Datasets/AnchorMeasurements/AnchorMeshes' + str(page_num) + '.json',
                                          'w') as outfile:
                                    json.dump(global_anchor_data, outfile)


def putting_into_latencymatrix(path, output):
    list_of_measurements = {}

    # Iterate on folder and read the json files in it
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith(".json"):
                with open(os.path.join(root, file)) as fp:
                    list_of_measurements.update(json.load(fp))

    df = pd.DataFrame(list_of_measurements)
    print(df.head())
    print(df.shape)
    df.to_csv(output)
    return df

if __name__ == '__main__':
    num_of_pages = 76
    for i in range(1,num_of_pages):
        print(i)
        infer_anchors(i)